/** Throwaway top/statusline comparison on the shared project/dialog workbench. */
import { Text } from 'ink';

import type { TuiViewModel } from '../../application/tui/view-model.js';
import { modelInfo } from './dialog-prototype.js';
import { displayWidth, truncateToDisplayWidth } from './render/width.js';
import { tuiColors } from './theme.js';

export type StatusVariant = 'current' | 'fixed' | 'custom';
export type StatusSlot = 'graph' | 'budget' | 'revision';
export type StatusAvailability = 'available' | 'unset' | 'unavailable';
export const statusVariants: readonly StatusVariant[] = ['current', 'fixed', 'custom'];
export const statusSlots: readonly StatusSlot[] = ['graph', 'budget', 'revision'];
export const prototypeSessionLabel = (id: string | null) => id === 'session-long-中文规划-2026' ? 'S-A'
  : id === 'session-b' ? 'S-B' : id === null ? '无' : truncateToDisplayWidth(id, 8);

function alertLines(items: readonly string[], width: number): readonly string[] {
  const groups: string[][] = [];
  let hidden = 0;
  for (const item of items) {
    const last = groups.at(-1);
    if (last !== undefined && displayWidth(`! ${[...last, item].join(' · ')}`) <= width) last.push(item);
    else if (groups.length < 2) groups.push([item]);
    else hidden += 1;
  }
  if (hidden > 0) {
    const last = groups.at(-1)!;
    while (last.length > 1 && displayWidth(`! ${last.join(' · ')} · 另有 ${hidden} 项`) > width) {
      last.pop();
      hidden += 1;
    }
    const suffix = ` · 另有 ${hidden} 项`;
    return groups.map((group, index) => index === groups.length - 1
      ? `${truncateToDisplayWidth(`! ${group.join(' · ')}`, width - displayWidth(suffix))}${suffix}`
      : truncateToDisplayWidth(`! ${group.join(' · ')}`, width));
  }
  return groups.map((group) => truncateToDisplayWidth(`! ${group.join(' · ')}`, width));
}

export function prototypeChrome(view: TuiViewModel, width: number, unread: boolean) {
  const control = ({ active: '运行', blocked: '阻塞', paused: '暂停', cancelling: '取消中', cancelled: '已取消' } as Record<string, string>)[view.scope.controlState] ?? view.scope.controlState;
  const holder = view.scope.executionLeaseHolderSessionId;
  const facts = [
    prototypeSessionLabel(view.selectedSessionId),
    `${view.scope.mode === 'route_planning' ? '规划' : '执行'}/${control}`,
    `待答${view.interactions.filter((item) => item.state === 'open').length}`,
    ...(holder !== null && holder !== view.selectedSessionId ? [`持有${prototypeSessionLabel(holder)}`] : []),
    ...(unread ? ['新消息'] : []),
  ].join(' · ');
  // Repository labels are fixtures; reserve space for the scope/session facts first.
  const repository = truncateToDisplayWidth(width < 100 ? 'orca-c/main' : 'orca-companion/main',
    Math.max(0, width - displayWidth(facts) - 3));
  const identity = truncateToDisplayWidth(repository ? `${repository} · ${facts}` : facts, width);
  const risks = [
    view.execution.reconciliation.pending ? '原操作结果未知 · 待对账' : null,
    view.scope.controlState === 'cancelling' ? '停止结果待核验' : null,
    view.execution.hazards.unverifiedWorkerCount > 0 ? 'Worker 状态待核验' : null,
    view.compaction?.status === 'context_exhausted' ? '上下文耗尽' : null,
    view.blockers.length > 0 ? `阻塞 ${view.blockers.length} 项 · Ctrl+B 查看依据` : null,
    view.compaction?.status === 'compaction_degraded' ? '压缩降级' : null,
    view.maintenance?.stopped ? '维护已停止' : null,
  ].filter((item): item is string => item !== null);
  return { identity, alerts: alertLines(risks, width) };
}

export function PrototypeStatusLine(props: {
  view: TuiViewModel;
  configurationRef: string;
  effort: string | null | undefined;
  availability: StatusAvailability;
  contextAvailable: boolean;
  width: number;
  variant: StatusVariant;
  slot: StatusSlot;
}) {
  const info = modelInfo[props.configurationRef];
  const effort = props.availability === 'unavailable' ? '不可用'
    : info === undefined ? '不可用' : info.efforts.length === 0 ? '不支持'
      : props.availability === 'unset' ? '未设置' : props.effort === null ? '未设置' : props.effort ?? info.defaultEffort ?? '未设置';
  // Context samples are explicit per-session fixtures, never inferred from billed usage.
  const context = props.availability !== 'available' || !props.contextAvailable ? '不可用'
    : props.view.selectedSessionId === 'session-b' ? '28%' : '62%';
  const tail = ` · 推理 ${effort} · 上下文 ${context}`;
  const label = info?.model ?? '模型不可用';
  const model = truncateToDisplayWidth(label, Math.max(1, props.width - displayWidth(tail)));
  const base = truncateToDisplayWidth(model + tail, props.width);
  const optional = props.slot === 'graph' ? props.view.graph === null ? '图不可用' : `G${props.view.graph.generation ?? '?'} v${props.view.graph.graphVersion}`
    : props.slot === 'budget' ? props.view.budgets[0] === undefined ? '预算未登记' : `已用 ${props.view.budgets[0].consumed}`
      : `rev ${props.view.scope.revision}`;
  // Only the optional field gives way; the three mandatory fields keep the same width budget.
  const line = props.variant === 'custom' && displayWidth(`${base} · ${optional}`) <= props.width ? `${base} · ${optional}` : base;
  return <Text color={tuiColors.muted}>{line}</Text>;
}
