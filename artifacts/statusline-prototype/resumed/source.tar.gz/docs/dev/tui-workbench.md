# TUI 调试工作台

先运行 `pnpm install` 和 `pnpm build`。预览只加载构建后的 `TuiApp` 与固定假端口，不连接模型、Orca、tracker 或协调存储；提交和 Scope 控制会显示 `preview_read_only` 拒绝。

在交互式终端运行 `pnpm ui:preview planning`。可选场景为 `planning`、`execution`、`blocked`、`empty`、`long-cjk`。预览要求 stdin/stdout 都是 TTY；`Esc` 关闭覆盖层，`Ctrl+C` 退出。改动源码后重新构建并启动预览。

主工作区临时原型运行 `pnpm ui:prototype planning`（同样可选上述场景）。`Ctrl+R` 打开消息历史，`Ctrl+T` 折叠或展开最新工具输出。原型内的思路摘要、消息和工具输出是固定假数据，不来自真实 Coordinator Session；原型代码位于 `src/interfaces/tui/workspace-prototype.tsx`。

执行图侧栏临时原型运行 `pnpm ui:graph-prototype execution`，也可选 `planning` 或 `blocked`。`Tab` 切换纵向分叉图与横向流向图，`M` 在三种场景间切换；节点位置只由固定依赖决定，运行态仅对当前 live 节点及入边施加短周期动效。使用固定的 Controller 快照假数据，经现有 `projectTuiViewModel` 投影，不连接真实执行后端。

图节点默认使用 [Nerd Fonts Material Design 图标](https://github.com/ryanoasis/nerd-fonts/blob/master/glyphnames.json)，图标后预留一个空格；运行动画通过项目已有 `@inkjs/ui` 的 `useSpinner` 驱动月相字形。侧栏底部提示图标异常时在选项中切回 ASCII。弹窗原型通过 `Ctrl+P → 选项 → ASCII` 切换；独立图原型按 `O` 打开图标选项。选择立即作用于图节点、运行动画和画布连线，切换会话或场景时保留本次打开的选择。ASCII 模式使用普通字符和 `-|/\\` 运行动画。启动时也可用 `ORCA_COMPANION_TUI_ICONS=ascii pnpm ui:dialog-prototype execution` 显式选择 ASCII。图标模式由用户选择，不依据终端环境猜测字体。此设置当前用于图原型，其他界面仍沿用现有符号。

更复杂的 12 节点图运行 `pnpm ui:graph-prototype execution large`。在 160 列及以上终端，侧栏图区域扩到 64 列；小终端沿用 40/24 列侧栏和折叠规则。其余场景与切换键位相同。

自适应压力原型运行 `pnpm ui:graph-prototype execution adaptive`：20 个节点，侧栏宽度随终端列数连续变化。图下保留带边框的选中节点卡片，区分标题、状态/Worker、依赖关系；前驱与后继显示准确编号。画布使用剩余高度，缩短层间距后围绕所选节点裁切，并显示图外节点数。当前节点与 blocker 保留在侧栏。`J/K` 逐节点移动焦点并高亮入边，`F` 回到当前执行节点，`Tab` 与 `M` 沿用布局/场景切换。项目面板与弹窗原型也复用这张卡片；全屏“执行图检查”显示依赖名称，并增加执行依据、工作范围和完整身份栏目，Tab 切信息，Enter 阅读完整详情。截图与检查见 `artifacts/dialog-prototype/README.md`。

Composer 的 slash 对照直接运行 `pnpm ui:composer-prototype slash above`，或把末尾改为 `inside`：B 在输入框上方显示独立候选框，A 在同一个输入框边框内展开候选。无参数时默认 B；`Ctrl+T` 切换方案，输入 `/` 后继续输入可过滤。B 列出所有匹配项，当前可用项反色高亮；↑↓ 改变高亮项，`Tab`／Enter 填入它，Esc 关闭。`Ctrl+P` 打开全局 Command Palette 作对照。长文、图片与待答背景场景仍可选 `typing`、`long`、`images`、`answer`，末尾可追加 `inline` 或 `review`；`Ctrl+N` 切换假 Session，`Ctrl+A` 切换绑定待答问题的回答模式，`Ctrl+L` 加载长文本，`Ctrl+O`／`Ctrl+D` 添加／移除模拟图片。图片仅用元数据演示，Enter 只显示模拟提交提示。此入口沿用固定 Controller 快照投影与 #40 continuous transcript 原型。截图和主流 CLI 对照见 `artifacts/composer-prototype/README.md`。

顶栏／状态行对照运行 `pnpm ui:status-prototype blocked fixed`，可选 `planning`、`execution`、`blocked`、`answer`、`idle`，末尾可选 `current`、`fixed`、`custom`。此入口共用已选定的项目面板、四类弹窗、continuous transcript、composer 与 adaptive 图。`Ctrl+T` 对比方案，`Ctrl+Y` 换场景，`Ctrl+O` 轮换普通附加字段，`Ctrl+W` 显示/清除通知，`Ctrl+E` 比较推理未设置及来源不可用；普通 `1/m/n/s` 进入输入框。固定与自选均常驻选中会话模型、effort 和可靠上下文占用，通知单独显示；自选字段空间不足时让位。风险最多两行，跨会话待答及另一执行持有者保留。`Ctrl+B` 使用已选定的项目面板，`Ctrl+P/Ctrl+S` 进入原弹窗，Esc 逐层返回。模型/effort 与菜单共用示例目录；切换模型后旧上下文百分比显示不可用。新版样例、独立源码副本、验证入口与 fixture/合同缺口见 [状态行原型说明](../../artifacts/statusline-prototype/README.md)；旧截图与弹窗定稿归档保留。

项目面板原型运行 `pnpm ui:project-prototype planning tabs`，五种场景为 `planning`、`execution`、`blocked`、`answer`、`idle`。用户已选定 `tabs`（栏目切换），`sections` 和 `menu` 留作比较资产。默认界面保留原 adaptive 图侧栏；`Ctrl+B` 开合项目面板并保留原栏目。120 列时项目面板使用原 sidebar 区域，对话与 composer 保持原位；80/50 列时仅在主区域显示项目面板。面板外框在同一终端尺寸下保持位置、宽度和高度，栏目、列表、详情与审阅内容在内部切换或滚动。项目面板只承载待答、预算/授权、完整身份、工作依据和事件；图与进度/即时状态保留在默认 sidebar，`Ctrl+G` 打开独立图检查。`Ctrl+T` 切比较方案、`Ctrl+Y` 切场景；`Tab` 切总览/待答/事件，方向键选择、Enter 下钻、Esc 逐层返回。待答列表显式跳到所属会话回答，`Ctrl+R` 返回原列表和会话；`Ctrl+N` 模拟新消息、`Ctrl+U` 模拟图/问题不可读。标题用青色分组，操作用箭头/选中底色，说明用次要文字，详情区分字段与值；无色时仍有分组、箭头和当前栏目方括号。复现检查、截图及示例字段说明见 `artifacts/project-panel-prototype/README.md`。原型使用固定假数据。

临时弹窗原型运行 `pnpm ui:dialog-prototype planning`，仍使用项目面板的五场景、栏目导航、草稿、continuous transcript 与 adaptive 图。`Ctrl+S` 打开带分隔线的会话身份摘要；`Ctrl+P` 打开左名称、右说明的紧凑命令目录。Model Picker 按 Planning / Execution 列出角色的当前配置，Enter 打开该角色模型菜单：候选行只显示 provider/model，下方横向 effort 选择器只提供该模型支持的选项。Tab 切列表/effort/按钮，↑↓ 选模型，←→ 改 effort 或按钮，Enter 前进或执行，Esc 丢弃菜单草稿。授权、交接、Cancel 使用分栏字段审阅；Tab 切栏目，↑↓ 浏览，←→ 选择返回/确认，Enter 执行。动作按钮的当前选项用反色色块表示。项目总览的“查看候选授权”打开同一审阅弹窗。`Ctrl+N` 模拟新消息，`Ctrl+U` 模拟不可读，弹窗关闭后 `Ctrl+Y` 换场景；`Ctrl+C` 打开退出确认。所有业务意图只经内存假端口演示，角色配置与 effort 仅在原型展示态保存；截图、复现检查与生产合同缺口见 `artifacts/dialog-prototype/README.md`。

该弹窗原型已由用户确认定稿。[最终设计、源码归档和三档 Nerd Fonts/ASCII 样例](../../artifacts/dialog-prototype/final/README.md) 是实施规划的直接输入；不要将早期比较图当作定稿重新探索。源码归档单独保留当前工作台、假数据、依赖锁文件与合同文档。

## 检查组件

两个终端分别运行：

```sh
pnpm ui:devtools
DEV=true pnpm ui:preview execution
```

React DevTools 可检查组件树并临时调整 props；试出的值需再写回源码。`DEV=true` 只用于开发，不会让预览接入真实业务端口。

## 采集真实终端画面

```sh
pnpm build
pnpm exec tuistory -s companion-ui --cols 120 --rows 40 -- node scripts/tui-preview.mjs long-cjk
pnpm exec tuistory -s companion-ui snapshot --trim
pnpm exec tuistory -s companion-ui screenshot
pnpm exec tuistory -s companion-ui resize 80 24
pnpm exec tuistory -s companion-ui snapshot --trim
pnpm exec tuistory -s companion-ui screenshot
pnpm exec tuistory -s companion-ui resize 50 40
pnpm exec tuistory -s companion-ui snapshot --trim
pnpm exec tuistory -s companion-ui screenshot
pnpm exec tuistory -s companion-ui close
```

画面中检查中文和长路径的裁切、Sidebar 折叠、焦点、选中项及警告文字。PNG 用于人工比较；字体和颜色取决于采集环境。`tests/tui/pty.test.ts` 使用同一个预览入口验收真实 resize 与终端恢复。
tuistory 连续 resize 后的截图可能带入旧尺寸的缓冲帧；需要干净的对比图时，关闭会话并按目标尺寸重新启动。旧帧是否残留在真实终端画面，以 PTY 用例的当前 pane 检查为准。
