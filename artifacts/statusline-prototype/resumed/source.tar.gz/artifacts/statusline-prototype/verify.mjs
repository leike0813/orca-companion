/** Shared workbench comparison: build first, then run this file [--capture]. */
import assert from 'node:assert/strict';
import { mkdirSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import process from 'node:process';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath, pathToFileURL, URL } from 'node:url';
import { launchTerminal } from 'tuistory';
import { displayWidth } from '../../dist/src/interfaces/tui/render/width.js';

const root = fileURLToPath(new URL('../../', import.meta.url));
const output = new URL('./resumed/', import.meta.url);
const capture = process.argv.includes('--capture');
const sizes = [[120, 40], [80, 24], [50, 40]];
const records = [];
const fromTuistory = createRequire(createRequire(import.meta.url).resolve('tuistory'));
const imageModule = fromTuistory.resolve('ghostty-opentui/image');
const { renderTerminalToImage } = await import(imageModule);
const { StyleFlags } = await import(new URL('./ffi.js', pathToFileURL(imageModule)));
if (capture) mkdirSync(output, { recursive: true });

async function frame(s) {
  await s.text();
  const d = s.getTerminalData();
  return d.lines.slice(-d.rows).map((l) => l.spans.map((p) => p.text).join('').trimEnd()).join('\n');
}
async function tap(s, key) { await s.press(key); return frame(s); }
async function ready(s, predicate) {
  for (let i = 0; i < 30; i++) {
    const text = await frame(s);
    if (predicate(text)) return text;
    await sleep(50);
  }
  assert.fail('画面未收敛：\n' + await frame(s));
}
async function run(scene, variant, size, body, color = false) {
  const env = { ...process.env, FORCE_COLOR: color ? '1' : '0', TERM: 'xterm-256color' };
  if (color) delete env.NO_COLOR;
  else env.NO_COLOR = '1';
  const s = await launchTerminal({ command: process.execPath, args: ['scripts/tui-preview.mjs', '--status-prototype', scene, variant],
    cols: size[0], rows: size[1], cwd: root, env });
  try { await ready(s, (t) => t.includes(`原型 ${variant}`)); await body(s); } finally { s.close(); }
}
async function shot(s, name, size) {
  const text = await frame(s);
  assert(text.split('\n').every((line) => displayWidth(line) <= size[0]), '终端画面超宽');
  if (!capture) return;
  const filename = `${name}-${size.join('x')}`;
  writeFileSync(new URL(filename + '.txt', output), text + '\n');
  const data = s.getTerminalData();
  const cells = { ...data, lines: data.lines.slice(-data.rows).map((line) => ({ ...line,
    spans: line.spans.flatMap((span) => Array.from(span.text, (text) => ({ ...span, text, width: displayWidth(text),
      ...((span.flags & StyleFlags.INVERSE) !== 0 ? { fg: span.fg ?? '#c0caf5', bg: span.bg ?? '#1a1b26' } : {}),
    }))),
  })) };
  writeFileSync(new URL(filename + '.png', output), await renderTerminalToImage(cells));
  records.push({ name, columns: size[0], rows: size[1], png: filename + '.png', text: filename + '.txt' });
}
const sessionOf = (text) => text.split('\n')[0].match(/S-[AB]/)?.[0];
const modelLine = (text) => text.split('\n').find((l) => /推理.*上下文/.test(l));
const command = async (s, query) => { await tap(s, ['ctrl', 'p']); await s.type(query); return tap(s, 'enter'); };
async function back(s) {
  for (let i = 0; i < 6; i++) {
    if (/原型 .* · [a-z]+ · 对话 · 滚动/.test(await frame(s))) return;
    await tap(s, 'esc');
  }
  assert.fail('未返回原对话');
}

for (const size of sizes) {
  for (const variant of ['current', 'fixed', 'custom']) {
    for (const scene of ['planning', 'execution', 'blocked', 'answer', 'idle']) {
      await run(scene, variant, size, async (s) => {
        const text = await frame(s);
        if (variant !== 'current') {
          assert.equal(sessionOf(text), 'S-A');
          assert.match(text, /待答[03]/);
          assert.match(modelLine(text) ?? '', /示例模型 A.*high.*62%/);
          assert(text.split('\n').filter((line) => line.startsWith('!')).length <= 2);
          if (scene === 'blocked') assert.match(text.split('\n').slice(0, 3).join('\n'), /未知.*待对账[\s\S]*持有S-B|持有S-B[\s\S]*未知.*待对账/);
        }
        await shot(s, `${variant}-${scene}`, size);
      }, capture);
    }
  }
  await run('blocked', 'fixed', size, async (s) => {
    await s.type('1mns-draft-中文'); await tap(s, 'pageup');
    const original = modelLine(await frame(s));
    const notified = await tap(s, ['ctrl', 'w']);
    assert.equal(modelLine(notified), original);
    assert(notified.includes('1mns-draft-中文') && notified.includes('待对账'));
    await shot(s, 'notification', size);
    await tap(s, ['ctrl', 'b']);
    assert((await frame(s)).includes('项目面板') && (await frame(s)).includes('待对账'));
    await shot(s, 'project', size);
    await tap(s, 'tab'); await tap(s, 'tab');
    for (const [cols, rows] of sizes) {
      s.resize({ cols, rows });
      await ready(s, (t) => t.includes('最近事件') && t.includes('待对账') && t.split('\n').every((l) => displayWidth(l) <= cols));
    }
    s.resize({ cols: size[0], rows: size[1] });
    await ready(s, (t) => t.includes('最近事件'));
    const closed = await tap(s, ['ctrl', 'b']);
    assert(closed.includes('1mns-draft-中文') && closed.includes('滚动2'));
    await tap(s, ['ctrl', 's']); await s.type('S-B'); await tap(s, ['ctrl', 'n']);
    assert.equal(sessionOf(await frame(s)), 'S-A');
    await shot(s, 'session-dialog-risk', size);
    await tap(s, 'esc');
    assert((await frame(s)).includes('1mns-draft-中文'));
    await tap(s, ['ctrl', 's']); await s.type('S-B'); await tap(s, 'enter');
    assert.equal(sessionOf(await frame(s)), 'S-B');
    assert.match(modelLine(await frame(s)) ?? '', /28%/);
    await shot(s, 'other-session', size);
  });
  await run('planning', 'fixed', size, async (s) => {
    await s.type('source-draft');
    for (const state of ['unset', 'unavailable', 'available']) {
      const text = await tap(s, ['ctrl', 'e']);
      const line = modelLine(text) ?? '';
      assert.match(line, state === 'unset' ? /推理 未设置.*上下文 不可用/ : state === 'unavailable' ? /推理 不可用.*上下文 不可用/ : /high.*62%/);
      await shot(s, `source-${state}`, size);
    }
    for (const variant of ['custom', 'current', 'fixed']) {
      const text = await tap(s, ['ctrl', 't']);
      assert(text.includes(`原型 ${variant}`) && text.includes('source-draft'));
    }
    await tap(s, ['ctrl', 't']);
    for (const slot of ['budget', 'revision', 'graph']) {
      const text = await tap(s, ['ctrl', 'o']);
      assert(text.includes(`^O${slot}`) && text.includes('source-draft'));
      assert.match(modelLine(text) ?? '', /high.*62%/);
      if (slot === 'revision' && size[0] === 120) assert.match(modelLine(text) ?? '', /rev 7/);
      await shot(s, `custom-slot-${slot}`, size);
    }
    await tap(s, ['ctrl', 't']); await tap(s, ['ctrl', 't']);
    await command(s, 'model'); await tap(s, 'enter'); await s.type('config-basic');
    await tap(s, 'enter'); await tap(s, 'enter');
    await back(s);
    assert.match(modelLine(await frame(s)) ?? '', /示例模型 D.*推理 不支持.*上下文 不可用/);
    await shot(s, 'model-no-effort', size);
    await command(s, 'model'); await tap(s, 'enter'); await s.type('config-b');
    await tap(s, 'enter'); await tap(s, 'right'); await tap(s, 'enter'); await tap(s, 'enter');
    await back(s);
    assert.match(modelLine(await frame(s)) ?? '', /示例模型 B.*推理 low.*上下文 不可用/);
    assert((await frame(s)).includes('source-draft'));
    await shot(s, 'model-changed', size);
    await command(s, 'model'); await tap(s, 'enter'); await s.type('config-rejected');
    await tap(s, 'enter'); await tap(s, 'enter'); await tap(s, 'enter');
    assert((await frame(s)).includes('被拒绝'));
    await back(s);
    assert.match(modelLine(await frame(s)) ?? '', /示例模型 B.*low/);
  });
  process.stdout.write(`✓ 五场景/三方案、通知、来源、模型、返回与 resize ${size.join('x')}\n`);
}
if (capture) writeFileSync(new URL('samples.json', output), JSON.stringify({ capturedAt: new Date().toISOString(), ticket: 48,
  renderer: 'tuistory PTY + ghostty-opentui bundled Nerd Font and CJK fallback', samples: records }, null, 2) + '\n');
process.stdout.write(`通过；${capture ? `保存 ${records.length} 组 PNG/文本` : '未改写截图'}\n`);
