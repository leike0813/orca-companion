/**
 * MOD-07：TUI 进程入口（Owner: `m2-deliver-planning-tui`，D1）。
 *
 * TTY 门禁在这里，且必须在挂载 Ink **之前**：research 已实测「无 TTY + `useInput`」会抛 raw-mode
 * 错误却保持退出码 0，若把判断交给组件就无法区分真失败与假成功。因此本模块先检查 stdin/stdout，
 * 通过后才动态 import Ink 与 React——未通过时 Ink 根本没有被加载，stdout 也不会出现渲染帧。
 */

import type { CliIO } from '../interfaces/cli/doctor-command.js';
import type { ComposedTuiPorts } from './tui-composition.js';

export const TUI_NO_TTY_CODE = 2;

export type TuiEntryEnvironment = {
  readonly cwd: string;
  readonly env: Readonly<Record<string, string>>;
  readonly stdinIsTty: boolean;
  readonly stdoutIsTty: boolean;
  /** 初始终端宽度；运行中由 Ink 的 `useStdout` 提供实时值。 */
  readonly columns: number;
};

export type TuiEntryDependencies = {
  /** 覆盖点：测试注入 fake 端口与渲染器；生产不替换。 */
  readonly createPorts?: (environment: TuiEntryEnvironment) => Promise<ComposedTuiPorts> | ComposedTuiPorts;
  readonly render?: RenderLike;
};

export type RenderedAppLike = {
  readonly unmount: () => void;
  readonly waitUntilExit: () => Promise<void>;
};

export type RenderLike = (
  element: unknown,
  options: { readonly exitOnCtrlC: boolean; readonly interactive: boolean },
) => RenderedAppLike;

/**
 * 判断是否可以在当前进程挂载前台 TUI。
 *
 * 两个流都必须有 TTY：stdin 无 TTY 时 `useInput` 无法进入 raw mode，stdout 无 TTY 时渲染帧会污染
 * 机器输出。失败关闭：不降级为一次性输出。
 */
export function assertInteractiveTty(environment: TuiEntryEnvironment): string | null {
  const missing: string[] = [];
  if (!environment.stdinIsTty) {
    missing.push('stdin');
  }
  if (!environment.stdoutIsTty) {
    missing.push('stdout');
  }
  return missing.length === 0 ? null : missing.join(' 与 ');
}

export async function runTuiEntry(
  environment: TuiEntryEnvironment,
  io: CliIO,
  dependencies: TuiEntryDependencies = {},
): Promise<number> {
  const missing = assertInteractiveTty(environment);
  if (missing !== null) {
    io.writeStderr(
      `orca-companion: 前台 TUI 需要交互式终端，但 ${missing} 没有 TTY；请改用 status 或 doctor。\n`,
    );
    return TUI_NO_TTY_CODE;
  }

  const composed = await (dependencies.createPorts ?? createDefaultPorts)(environment);
  const ports = composed.ports;
  const renderElement: RenderLike =
    dependencies.render ??
    (await import('ink')).render.bind(undefined) as unknown as RenderLike;
  const { createElement } = await import('react');
  const { TuiApp } = await import('../interfaces/tui/app.js');

  // `onExit` 只在渲染完成后被调用，因此闭包引用 `app` 不存在暂时性死区问题。
  //
  // `interactive: true` 必须显式给出：Ink 7 默认用 `!isInCi && stdout.isTTY` 判断，只要环境里有
  // `CI=true`（用户 shell 里导出过也算），即使 stdin/stdout 都是真 TTY 也不会绘制任何帧，界面表现为
  // 永久空白。交互性的真实前提已由上面的双 TTY 门禁核验，不由环境变量猜测。
  const app = renderElement(
    createElement(TuiApp, {
      ports,
      terminalWidth: environment.columns,
      initialScopeId: null,
      onExit: () => {
        app.unmount();
      },
    }),
    { exitOnCtrlC: false, interactive: true },
  );
  try {
    await app.waitUntilExit();
  } finally {
    // 退出只清理本进程资源：不隐式 Pause/Cancel 任何 Scope 或 Session。
    composed.close();
  }
  return 0;
}

async function createDefaultPorts(environment: TuiEntryEnvironment): Promise<ComposedTuiPorts> {
  const { createTuiPorts } = await import('./tui-composition.js');
  return await createTuiPorts(environment);
}
